"""GSE profile comparison — replicates the original dashboard methodology.

Two normalisation modes:
    - Monorario (PDMM, PAUM, PIRM, PACM, MDMM, MAUM):
        each hour expressed as % of monthly consumption (sum over 24h × n_days ≈ 100%)
    - Fasce / Time-of-Use (PDMF, PAUF, PIRF, PACF, MDMF, MAUF):
        each hour expressed as % of monthly consumption of *its own ARERA band*
        (F1 = Mon-Fri 08-18, F2 = Mon-Fri 07,19-22 + Sat 07-22, F3 = nights/Sunday)

The dispatch happens automatically based on the profile_code suffix.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from sqlalchemy import text
from sqlalchemy.orm import Session

Q_COLS = [f"q{i}" for i in range(1, 97)]

# Profile codes that use the in-fasce (time-of-use) normalisation
FASCIA_CODES = {"PDMF", "PAUF", "PIRF", "PACF", "MDMF", "MAUF"}


def _hourly_sum_expr() -> str:
    """SQL expression list: 24 hourly kWh values built from the 96 quarter-hour
    columns. Each h_N = (q[4N+1] + q[4N+2] + q[4N+3] + q[4N+4]) / 1000 (kWh)."""
    return ", ".join(
        f"(COALESCE(q{4*h+1},0)+COALESCE(q{4*h+2},0)"
        f"+COALESCE(q{4*h+3},0)+COALESCE(q{4*h+4},0))/1000.0 AS h{h}"
        for h in range(24)
    )


# ── Monorario: dashboard's `compute_our_normalized_profiles` ─────────────────
def _fetch_monorario(
    session: Session,
    pods:    list[str],
    dayset:  str,
    tipologia: str,
) -> pd.DataFrame:
    """Per-month % of monthly consumption per hour (matches GSE monorario scale)."""
    if dayset == "weekday":
        dow_filter = "AND EXTRACT(ISODOW FROM data_misura) BETWEEN 1 AND 5"
    elif dayset == "weekend":
        dow_filter = "AND EXTRACT(ISODOW FROM data_misura) >= 6"
    elif dayset == "all":
        dow_filter = ""
    else:
        raise ValueError(f"Unknown dayset: {dayset!r}")

    # SQL plan:
    #   1. per_pod_month: avg kWh per hour over all days of that POD/month,
    #      plus n_days = distinct days present
    #   2. with_pct: pct per hour = avg_h / (total_24h_avg * n_days) * 100
    #      → that's hour / monthly_total
    #   3. final: average pct across PODs per (month, hour)
    avg_per_hour = ", ".join(f"AVG(h{h}) AS avg_h{h}" for h in range(24))
    sum_of_avgs  = " + ".join(f"AVG(h{h})" for h in range(24))
    sql = text(
        f"""
        WITH per_row AS (
            SELECT pod, EXTRACT(MONTH FROM data_misura)::int AS month_idx,
                   data_misura, {_hourly_sum_expr()}
            FROM measurements
            WHERE tipologia = :tipologia AND pod = ANY(:pods) {dow_filter}
        ),
        per_pod_month AS (
            SELECT pod, month_idx, {avg_per_hour},
                   ({sum_of_avgs}) AS daily_total_avg,
                   COUNT(DISTINCT data_misura) AS n_days
            FROM per_row
            GROUP BY pod, month_idx
        ),
        with_pct AS (
            SELECT pod, month_idx,
                {", ".join(f"avg_h{h} / NULLIF(daily_total_avg * n_days, 0) * 100 AS p{h}"
                            for h in range(24))}
            FROM per_pod_month
        )
        SELECT month_idx, {", ".join(f"AVG(p{h}) AS h{h}" for h in range(24))}
        FROM with_pct
        GROUP BY month_idx
        ORDER BY month_idx
        """
    )
    rows = session.execute(sql, {"tipologia": tipologia, "pods": pods}).all()
    return _rows_to_long(rows)


# ── Fascia: dashboard's `compute_our_fascia_profiles` ────────────────────────
def _hour_to_fascia_pct_expr(h: int) -> str:
    """SQL expression: per-hour pct using the band-monthly denominator.

    Italian ARERA bands:
        F1 = Mon-Fri (iso_dow 1-5) & 08 <= h <= 18
        F2 = Mon-Fri & h == 7 or 19 <= h <= 22; Saturday (6) & 07 <= h <= 22
        F3 = everything else (Sunday, nights)
    """
    if 8 <= h <= 18:
        return (
            f"CASE "
            f"WHEN iso_dow BETWEEN 1 AND 5 THEN h{h} / NULLIF(f1_mo,0) * 100 "
            f"WHEN iso_dow = 6 THEN h{h} / NULLIF(f2_mo,0) * 100 "
            f"ELSE h{h} / NULLIF(f3_mo,0) * 100 END AS p{h}"
        )
    if h == 7 or 19 <= h <= 22:
        return (
            f"CASE "
            f"WHEN iso_dow BETWEEN 1 AND 6 THEN h{h} / NULLIF(f2_mo,0) * 100 "
            f"ELSE h{h} / NULLIF(f3_mo,0) * 100 END AS p{h}"
        )
    # h in {0..6, 23} → always F3
    return f"h{h} / NULLIF(f3_mo,0) * 100 AS p{h}"


def _fetch_fascia(
    session: Session,
    pods:    list[str],
    dayset:  str,
    tipologia: str,
) -> pd.DataFrame:
    """Per-month % of band-monthly consumption per hour (matches GSE fascia scale)."""
    if dayset == "weekday":
        dow_filter = "AND EXTRACT(ISODOW FROM data_misura) BETWEEN 1 AND 5"
    elif dayset == "weekend":
        dow_filter = "AND EXTRACT(ISODOW FROM data_misura) >= 6"
    elif dayset == "all":
        dow_filter = ""
    else:
        raise ValueError(f"Unknown dayset: {dayset!r}")

    f1_day = "(" + "+".join(f"h{h}" for h in range(8, 19)) + ")"
    f2_day_weekday = "(h7+" + "+".join(f"h{h}" for h in range(19, 23)) + ")"
    f2_day_sat     = "(" + "+".join(f"h{h}" for h in range(7, 23)) + ")"
    f3_day_weekday = "(" + "+".join(f"h{h}" for h in list(range(0, 7)) + [23]) + ")"
    f3_day_sat     = f3_day_weekday
    f3_day_sun     = "(" + "+".join(f"h{h}" for h in range(0, 24)) + ")"

    pct_exprs = ", ".join(_hour_to_fascia_pct_expr(h) for h in range(24))

    sql = text(
        f"""
        WITH per_row AS (
            SELECT pod, EXTRACT(MONTH FROM data_misura)::int AS month_idx,
                   EXTRACT(ISODOW FROM data_misura)::int AS iso_dow,
                   {_hourly_sum_expr()}
            FROM measurements
            WHERE tipologia = :tipologia AND pod = ANY(:pods) {dow_filter}
        ),
        per_row_with_fascia AS (
            SELECT *,
                CASE WHEN iso_dow BETWEEN 1 AND 5 THEN {f1_day} ELSE 0 END AS f1_d,
                CASE
                    WHEN iso_dow BETWEEN 1 AND 5 THEN {f2_day_weekday}
                    WHEN iso_dow = 6 THEN {f2_day_sat}
                    ELSE 0
                END AS f2_d,
                CASE
                    WHEN iso_dow = 7 THEN {f3_day_sun}
                    WHEN iso_dow = 6 THEN {f3_day_sat}
                    ELSE {f3_day_weekday}
                END AS f3_d
            FROM per_row
        ),
        monthly_fascia AS (
            SELECT pod, month_idx,
                SUM(f1_d) AS f1_mo, SUM(f2_d) AS f2_mo, SUM(f3_d) AS f3_mo
            FROM per_row_with_fascia
            GROUP BY pod, month_idx
        ),
        joined AS (
            SELECT p.*, m.f1_mo, m.f2_mo, m.f3_mo
            FROM per_row_with_fascia p
            JOIN monthly_fascia m USING (pod, month_idx)
        ),
        per_row_pct AS (
            SELECT pod, month_idx, iso_dow, {pct_exprs}
            FROM joined
        )
        SELECT month_idx, {", ".join(f"AVG(p{h}) AS h{h}" for h in range(24))}
        FROM per_row_pct
        GROUP BY month_idx
        ORDER BY month_idx
        """
    )
    rows = session.execute(sql, {"tipologia": tipologia, "pods": pods}).all()
    return _rows_to_long(rows)


def _smooth_holes(long: pd.DataFrame) -> pd.DataFrame:
    """Per-month linear interpolation of zero-valued holes.

    A "hole" is an hour whose value collapsed to zero while neighbouring hours
    are positive — typically a side-effect of sparse data and per-POD averaging.
    We replace those zeros with the linear interpolation of the neighbours.
    """
    if long.empty:
        return long
    out = long.copy().sort_index()
    months = out.index.get_level_values("month_idx").unique()
    for m in months:
        try:
            sub = out.xs(m, level="month_idx")
        except KeyError:
            continue
        s = sub["value"].astype(float)
        zeros = s == 0
        if not zeros.any() or zeros.all():
            continue  # nothing to fill or nothing to interpolate from
        s2 = s.where(~zeros, np.nan)
        s2 = s2.interpolate(method="linear", limit_direction="both").fillna(0.0)
        out.loc[(m, slice(None)), "value"] = s2.values
    return out


# ── Common reshape ───────────────────────────────────────────────────────────
def _rows_to_long(rows) -> pd.DataFrame:
    if not rows:
        return pd.DataFrame(columns=["value"])
    cols = ["month_idx"] + [f"h{h}" for h in range(24)]
    df = pd.DataFrame(rows, columns=cols)
    long = df.melt(
        id_vars="month_idx",
        value_vars=[f"h{h}" for h in range(24)],
        var_name="hour_idx", value_name="value",
    )
    long["hour_idx"] = long["hour_idx"].str[1:].astype(int)
    long["value"]    = long["value"].astype(float).fillna(0.0)
    long = long.set_index(["month_idx", "hour_idx"]).sort_index()
    return _smooth_holes(long)


# ── Public dispatcher ────────────────────────────────────────────────────────
def fetch_our_gse_normalised_profile(
    session:      Session,
    pods:         list[str] | set[str],
    dayset:       str = "weekday",
    profile_code: str = "PDMM",
    tipologia:    str = "AP",
) -> pd.DataFrame:
    """Pick the right normalisation based on the GSE profile_code:
    F* → in-fasce (TOU) normalisation, others → monorario.
    """
    if not pods:
        return pd.DataFrame(columns=["value"])
    pods = list(pods)
    if profile_code in FASCIA_CODES:
        return _fetch_fascia(session, pods, dayset, tipologia)
    return _fetch_monorario(session, pods, dayset, tipologia)


# ── Reference fetch ──────────────────────────────────────────────────────────
def fetch_gse_reference_profile(
    session:      Session,
    profile_code: str,
) -> pd.DataFrame:
    rows = session.execute(
        text(
            "SELECT month_idx, hour_idx, value "
            "FROM reference_profiles_gse "
            "WHERE profile_code = :code "
            "ORDER BY month_idx, hour_idx"
        ),
        {"code": profile_code},
    ).all()
    if not rows:
        return pd.DataFrame(columns=["value"])
    df = pd.DataFrame(rows, columns=["month_idx", "hour_idx", "value"])
    df["value"] = df["value"].astype(float)
    return df.set_index(["month_idx", "hour_idx"]).sort_index()


# ── Metrics ──────────────────────────────────────────────────────────────────
def compare_to_gse(
    our:       pd.DataFrame,
    reference: pd.DataFrame,
) -> pd.DataFrame:
    if our.empty or reference.empty:
        return pd.DataFrame(columns=["rmse", "mae", "max_abs_err", "bias"])

    joined = (
        our.rename(columns={"value": "ours"})
        .join(reference.rename(columns={"value": "ref"}), how="inner")
    )
    if joined.empty:
        return pd.DataFrame(columns=["rmse", "mae", "max_abs_err", "bias"])

    joined["err"] = joined["ours"] - joined["ref"]
    return (
        joined.groupby(level="month_idx")
        .agg(
            rmse       =("err", lambda s: float(np.sqrt(np.mean(s ** 2)))),
            mae        =("err", lambda s: float(np.mean(np.abs(s)))),
            max_abs_err=("err", lambda s: float(np.max(np.abs(s)))),
            bias       =("err", lambda s: float(np.mean(s))),
        )
    )
