"""Clustering Explorer tab."""

from __future__ import annotations

import pandas as pd
import streamlit as st

import api
from charts import centroid_chart, cluster_sizes_chart, fmt_int, pearson_heatmap
from components import ateco_filter
from helpers import fmt_label


TIPOLOGIA_LABELS = {
    "AP":  "Active Power Drawn (AP) [kWh]",
    "AN":  "Active Power Injected (AN) [kWh]",
    "RLP": "Reactive Power, Lagging — Drawn (RLP) [kVArh]",
    "RLN": "Reactive Power, Lagging — Injected (RLN) [kVArh]",
    "RCP": "Reactive Power, Capacitive — Drawn (RCP) [kVArh]",
    "RCN": "Reactive Power, Capacitive — Injected (RCN) [kVArh]",
}
NORM_LABELS    = {"minmax": "Min/Max", "max": "Max"}
LINKAGE_LABELS = {
    "ward": "Ward", "average": "Average", "complete": "Complete", "single": "Single",
}
LEVEL_NAMES = {1: "Level 1 — Section", 2: "Level 2 — Division", 3: "Level 3 — Class"}


# ── Result panel for a single clustering ────────────────────────────────────
def _render_panel(level_label: str, response: dict):
    m = response["metrics"]
    st.markdown(f"##### {level_label}")

    sizes = {int(k): v for k, v in m["sizes"].items()}

    # 1) Centroids chart
    st.plotly_chart(
        centroid_chart({int(k): v for k, v in response["centroids"].items()}, sizes,
                       title=f"Cluster Centroids — {level_label}"),
        use_container_width=True,
    )

    # 2) Cluster sizes chart
    st.plotly_chart(cluster_sizes_chart(sizes), use_container_width=True)

    # 3) Pearson correlation heatmap
    if response.get("pearson_matrix"):
        st.plotly_chart(
            pearson_heatmap(response["pearson_matrix"], response["pearson_labels"]),
            use_container_width=True,
        )

    # 4) Compact metrics table (replaces scattered st.metric widgets)
    st.markdown("###### Cluster Quality Metrics")
    metrics_rows = [
        ("PODs Clustered [-]",     fmt_int(m["n_pods"])),
        ("Number of Clusters [-]", fmt_int(m["n_clusters"])),
        ("Silhouette Score [-]",
         f"{m['silhouette']:.4f}" if m["silhouette"] is not None else "N/A"),
        ("Calinski–Harabasz [-]",
         f"{m['calinski_harabasz']:.1f}" if m["calinski_harabasz"] is not None else "N/A"),
        ("Davies–Bouldin [-]",
         f"{m['davies_bouldin']:.4f}" if m["davies_bouldin"] is not None else "N/A"),
    ]
    metrics_df = pd.DataFrame(metrics_rows, columns=["Metric", "Value"])
    st.dataframe(metrics_df, hide_index=True, use_container_width=True)

    # 5) Dominant ATECO codes per cluster
    st.markdown("###### Dominant ATECO Codes per Cluster")
    bdf = pd.DataFrame(response["ateco_breakdown"])
    if not bdf.empty:
        bdf = bdf.rename(columns={
            "cluster":        "Cluster",
            "ateco":          "ATECO",
            "description":    "Description",
            "n_pods":         "Number of PODs [-]",
            "pct_of_cluster": "Share of Cluster [%]",
        })
        st.dataframe(
            bdf.style.format({"Share of Cluster [%]": "{:.1f}",
                              "Number of PODs [-]":   lambda v: fmt_int(v)}),
            hide_index=True, use_container_width=True,
        )


def render():
    # Title + status placeholder (status appears next to title when running)
    title_c, status_c = st.columns([4, 2])
    with title_c:
        st.subheader("Clustering Explorer")
        st.caption(
            "Hierarchical clustering on the per-POD daily profile. ."
            "When you select codes at multiple ATECO levels a separate "
            "clustering runs for each level."
        )
    status_slot = status_c.empty()

    # ── ATECO catalogue + tipologie ─────────────────────────────────────────
    try:
        codes_l1 = api.ateco_codes(level=1)
        codes_l2 = api.ateco_codes(level=2)
        codes_l3 = api.ateco_codes(level=3)
        descs    = api.ateco_descriptions()
        tipologie_options = api.tipologie() or ["AP"]
    except api.BackendError as e:
        st.error(f"ATECO catalog unavailable: {e}.")
        return

    st.markdown("#### ATECO Level Selection")
    selected_l1, selected_l2, selected_l3 = ateco_filter.render(
        key_prefix="cl",
        codes_l1=codes_l1, codes_l2=codes_l2, codes_l3=codes_l3,
        descs=descs,
    )

    # ── Clustering parameters ──────────────────────────────────────────────
    st.markdown("#### Clustering Parameters")
    c1, c2, c3 = st.columns([2, 1, 1])
    with c1:
        tipologia = st.selectbox(
            "Measurement Type",
            options=tipologie_options,
            format_func=lambda t: TIPOLOGIA_LABELS.get(t, t),
            index=tipologie_options.index("AP") if "AP" in tipologie_options else 0,
            key="cl_tipologia",
        )
    with c2:
        cluster_mode = st.radio("Cluster Count Mode", ["Manual", "Auto"],
                                 horizontal=True, key="cl_mode")
    with c3:
        if cluster_mode == "Manual":
            n_clusters = st.slider("Number of Clusters", 2, 15, 5, key="cl_k")
        else:
            n_clusters = st.number_input("Suggested k (heuristic)",
                                          2, 15, 5, key="cl_k_auto")

    c4, c5, c6 = st.columns([1, 1, 1])
    with c4:
        normalise = st.selectbox(
            "Normalization",
            options=list(NORM_LABELS.keys()),
            format_func=lambda k: NORM_LABELS[k],
            index=0, key="cl_norm",
        )
    with c5:
        method = st.selectbox(
            "Linkage Method",
            options=list(LINKAGE_LABELS.keys()),
            format_func=lambda k: LINKAGE_LABELS[k],
            index=1, key="cl_method",
            help="Original dashboard uses 'Average' linkage."
        )
    with c6:
        min_months = st.number_input(
            "Minimum Months of Data per POD", 1, 36, 12, key="cl_min_months",
        )

    # ── POD preview ────────────────────────────────────────────────────────
    pod_filter = {
        "ateco_l1":   selected_l1 or None,
        "ateco_l2":   selected_l2 or None,
        "ateco_l3":   selected_l3 or None,
        "min_months": int(min_months),
        "tipologia":  tipologia,
    }
    try:
        preview = api.pod_set_preview(pod_filter)
        st.info(f"**{fmt_int(preview['n_pods'])} PODs** available "
                f"(coverage filter alone: {fmt_int(preview['after_coverage'])}).")
    except api.BackendError as e:
        st.error(f"Preview failed: {e}.")
        return

    # ── Run ────────────────────────────────────────────────────────────────
    if st.button("▶ Run Clustering", type="primary", key="cl_run"):

        if not (selected_l1 or selected_l2 or selected_l3):
            st.error("Select at least one ATECO code at any level.")
            return

        with status_slot.status("Aggregating profiles & clustering server-side.",
                                 expanded=False) as s:
            try:
                result = api.run_clustering_by_level({
                    "ateco_l1":   selected_l1 or None,
                    "ateco_l2":   selected_l2 or None,
                    "ateco_l3":   selected_l3 or None,
                    "min_months": int(min_months),
                    "tipologia":  tipologia,
                    "n_clusters": int(n_clusters),
                    "method":     method,
                    "normalise":  normalise,
                    "top_ateco_per_cluster": 5,
                })
                s.update(label="Clustering complete.", state="complete")
                st.session_state["clustering_last_result"] = {
                    "result":     result,
                    "tipologia":  tipologia,
                    "n_clusters": int(n_clusters),
                    "method":     method,
                    "normalise":  normalise,
                }
            except api.BackendError as e:
                s.update(label=f"Clustering failed: {e}.", state="error")
                return

    # ── Render the last stored result (persists across tab switches) ──────
    stored = st.session_state.get("clustering_last_result")
    if not stored:
        return

    result     = stored["result"]
    tipologia  = stored["tipologia"]
    n_clusters = stored["n_clusters"]
    method     = stored["method"]
    normalise  = stored["normalise"]

    if not result["results"]:
        st.warning("No level produced a clustering — check your filters.")
        return

    valid = [r for r in result["results"] if r["response"]["n_pods"] > 0]
    if not valid:
        st.warning("No level produced a non-empty clustering.")
        return

    cols = st.columns(len(valid))
    for col, lvl_result in zip(cols, valid):
        with col:
            level = lvl_result["level"]
            _render_panel(LEVEL_NAMES[level], lvl_result["response"])

    import json
    st.download_button(
        "⬇ Download Full Result (JSON)",
        data=json.dumps(result, indent=2).encode("utf-8"),
        file_name=f"clustering_{tipologia}_k{n_clusters}_{method}_{normalise}.json",
        mime="application/json",
    )
