"""SQL query helpers.

All heavy data-shaping is done in PostgreSQL (`GROUP BY`, `AVG`, …) so that
Python only receives the already-aggregated result. This is the central
advantage of moving from Parquet caches to a real database.

Every function takes a SQLAlchemy `Session` as input and returns either a
DataFrame, a Series, or a plain list/dict. No Streamlit, no FastAPI imports.
"""

from __future__ import annotations

import pandas as pd
from sqlalchemy import bindparam, text
from sqlalchemy.orm import Session

Q_COLS = [f"q{i}" for i in range(1, 97)]


# ── Aggregated profiles (the core query) ─────────────────────────────────────
def _view_exists(session: Session) -> bool:
    """Check whether `pod_avg_profile` materialized view exists."""
    return bool(session.execute(text(
        "SELECT to_regclass('public.pod_avg_profile')"
    )).scalar())


def fetch_aggregated_profiles(
    session: Session,
    pod_ids: set[str] | list[str] | None = None,
    tipologia: str = "AP",
) -> pd.DataFrame:
    """Per-POD average daily profile (96 quarter-hour values).

    Uses the `pod_avg_profile` materialized view when present (≪1 s for any
    POD subset), otherwise falls back to an on-the-fly GROUP BY on
    `measurements` (~10 s on 4.3 M rows).
    """
    q_cols = ", ".join(Q_COLS)
    if _view_exists(session):
        if pod_ids:
            sql = text(
                f"SELECT pod, {q_cols} FROM pod_avg_profile "
                "WHERE tipologia = :tipologia AND pod = ANY(:pod_ids)"
            )
            params = {"tipologia": tipologia, "pod_ids": list(pod_ids)}
        else:
            sql = text(
                f"SELECT pod, {q_cols} FROM pod_avg_profile "
                "WHERE tipologia = :tipologia"
            )
            params = {"tipologia": tipologia}
    else:
        q_avg = ", ".join(f"AVG({q}) AS {q}" for q in Q_COLS)
        if pod_ids:
            sql = text(
                f"SELECT pod, {q_avg} "
                "FROM measurements "
                "WHERE tipologia = :tipologia AND pod = ANY(:pod_ids) "
                "GROUP BY pod"
            )
            params = {"tipologia": tipologia, "pod_ids": list(pod_ids)}
        else:
            sql = text(
                f"SELECT pod, {q_avg} "
                "FROM measurements "
                "WHERE tipologia = :tipologia "
                "GROUP BY pod"
            )
            params = {"tipologia": tipologia}

    rows = session.execute(sql, params).all()
    if not rows:
        return pd.DataFrame(columns=Q_COLS)
    df = pd.DataFrame(rows, columns=["pod", *Q_COLS]).set_index("pod")
    return df


# ── Coverage filter (≥ N months of data) ─────────────────────────────────────
def fetch_pods_with_data_coverage(
    session: Session,
    min_months: int = 12,
    tipologia: str = "AP",
) -> set[str]:
    """Return PODs that have at least ``min_months`` distinct calendar months
    of measurements for the given tipologia."""
    sql = text(
        "SELECT pod "
        "FROM measurements "
        "WHERE tipologia = :tipologia "
        "GROUP BY pod "
        "HAVING COUNT(DISTINCT date_trunc('month', data_misura)) >= :min_months"
    )
    rows = session.execute(
        sql, {"tipologia": tipologia, "min_months": min_months}
    ).all()
    return {r[0] for r in rows}


# ── POD selection by ATECO ────────────────────────────────────────────────────
def fetch_pods_by_ateco(
    session: Session,
    codes: list[str],
    level: int = 1,
) -> set[str]:
    """Return PODs whose ATECO code at the given hierarchy level matches one
    of the supplied codes."""
    if not codes:
        return set()
    col = {1: "ateco_l1", 2: "ateco_l2", 3: "ateco_l3"}.get(level)
    if col is None:
        raise ValueError(f"Invalid ATECO level: {level} (must be 1, 2 or 3)")
    sql = text(f"SELECT pod FROM pod_metadata WHERE {col} = ANY(:codes)")
    rows = session.execute(sql, {"codes": list(codes)}).all()
    return {r[0] for r in rows}


def fetch_ateco_codes(session: Session, level: int = 1) -> list[str]:
    """List all distinct ATECO codes seen at the given level in pod_metadata."""
    col = {1: "ateco_l1", 2: "ateco_l2", 3: "ateco_l3"}.get(level)
    if col is None:
        raise ValueError(f"Invalid ATECO level: {level}")
    sql = text(
        f"SELECT DISTINCT {col} FROM pod_metadata "
        f"WHERE {col} IS NOT NULL ORDER BY {col}"
    )
    return [r[0] for r in session.execute(sql).all()]


# ── Metadata fetch ────────────────────────────────────────────────────────────
def fetch_pod_metadata(
    session: Session,
    pod_ids: set[str] | list[str] | None = None,
) -> pd.DataFrame:
    """Return the pod_metadata table as a DataFrame (filtered if pod_ids given)."""
    if pod_ids:
        sql = text("SELECT * FROM pod_metadata WHERE pod = ANY(:pod_ids)")
        rows = session.execute(sql, {"pod_ids": list(pod_ids)}).mappings().all()
    else:
        rows = session.execute(text("SELECT * FROM pod_metadata")).mappings().all()
    return pd.DataFrame(rows)


# ── ATECO lookup ──────────────────────────────────────────────────────────────
def fetch_ateco_descriptions(session: Session) -> dict[str, str]:
    """Return a ``{code: description}`` dict for every ATECO entry."""
    rows = session.execute(
        text("SELECT code, description FROM ateco_lookup")
    ).all()
    return {code: (desc or "") for code, desc in rows}


# ── Tipologie distinte ─────────────────────────────────────────────────────────
def fetch_distinct_tipologie(session: Session) -> list[str]:
    """All distinct measurement type codes present in measurements."""
    sql = text("SELECT DISTINCT tipologia FROM measurements "
               "WHERE tipologia IS NOT NULL ORDER BY tipologia")
    return [r[0] for r in session.execute(sql).all()]


# ── Per-POD data-coverage gap stats ──────────────────────────────────────────
def fetch_pod_data_gaps(
    session: Session, pod_ids: list[str] | set[str],
    tipologia: str = "AP",
) -> pd.DataFrame:
    """For each POD: days with data, expected days (full date range),
    missing days, and missing %."""
    if not pod_ids:
        return pd.DataFrame(columns=[
            "pod", "days_with_data", "expected_days", "missing_days", "missing_pct"
        ])
    sql = text("""
        SELECT pod,
               COUNT(DISTINCT data_misura)                        AS days_with_data,
               (MAX(data_misura)::date - MIN(data_misura)::date) + 1 AS expected_days
        FROM measurements
        WHERE tipologia = :tipologia AND pod = ANY(:pods)
        GROUP BY pod
    """)
    rows = session.execute(
        sql, {"tipologia": tipologia, "pods": list(pod_ids)}
    ).all()
    if not rows:
        return pd.DataFrame(columns=[
            "pod", "days_with_data", "expected_days", "missing_days", "missing_pct"
        ])
    df = pd.DataFrame(rows, columns=["pod", "days_with_data", "expected_days"])
    df["missing_days"] = (df["expected_days"] - df["days_with_data"]).clip(lower=0)
    df["missing_pct"]  = (df["missing_days"] / df["expected_days"].clip(lower=1) * 100).round(2)
    return df


# ── Counts (used by /info, db-check, smoke tests) ────────────────────────────
def fetch_table_counts(session: Session) -> dict[str, int]:
    """Row counts for every main table — useful for health and smoke tests."""
    tables = (
        "pod_metadata", "measurements", "ateco_lookup",
        "reference_profiles_gse", "reference_profiles_arera",
    )
    counts: dict[str, int] = {}
    for t in tables:
        counts[t] = session.execute(text(f"SELECT count(*) FROM {t}")).scalar_one()
    return counts
